
import java.io.StringReader;
import java.util.Arrays;
import java.util.Scanner;


/*
 * 
 * Huffman Code Tree
 * 
 * SNUCSE
 * LJH_2018_02_19
 * 
 */


public class Main {
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		String line = "";
		Scanner scanner = new Scanner(System.in);
	
		MinHeap< HuffTree<Character> > Hheap = new MinHeap<>( (HuffTree<Character>[])new HuffTree[100], 0, 100 ); 
		HuffTree<Character> tree = null;	//target huffTree
		
		while (true) {
			line = scanner.nextLine();
			Scanner i_scanner = new Scanner(new StringReader(line));
			String cmd = i_scanner.next();

			if (cmd.equals("freq")) {
				char c = i_scanner.next().charAt(0); 			//store a character in c 
				int freq = Integer.valueOf(i_scanner.next());	//freq value 
				
				HuffTree<Character> t = new HuffTree<Character>(c, freq);
				Hheap.insert(t);	// make heap for each character 
				
			} else if (cmd.equals("build")) {	
				tree = buildTree(Hheap);	//target huffTree
				
			} else if (cmd.equals("encode")) {
				String res = encode(tree, i_scanner.next());
				System.out.println("encoded: " + res);
				
			} else if (cmd.equals("decode")) {
				String res = decode(tree, i_scanner.next());
				System.out.println("decoded: " + res);
				
			} else if (cmd.equals("show")) {
				show(tree.root(), "");
				//show(tree, "");
				
			} else if (cmd.equals("quit")) {
				i_scanner.close();
				break;
				
			} else {
				System.out.println("Wrong command!");
			}
			
			i_scanner.close();
		}
		
		scanner.close();
	}
	
	/*
	 * make HuffTree using minHeap
	 */
	
	public static HuffTree<Character> buildTree(MinHeap<HuffTree<Character>> Hheap) {
		
		assert Hheap.heapsize() > 0 : "heap is empty"; 
		
		while(Hheap.heapsize() != 1){
			HuffTree<Character> min1 = Hheap.removemin();
			HuffTree<Character> min2 = Hheap.removemin();
			int weight1 = min1.weight();
			int weight2 = min2.weight();
			int weightSum = weight1 + weight2;
			
			//make internal node
			HuffTree<Character> sum12 = new HuffTree<>(min2.root(), min1.root(), weightSum);
			Hheap.insert(sum12);
		}
		
		return Hheap.removemin();
	}
	
	/*
	 * find a character in the huffTree and change it to the String of numbers
	 * which is a path from the root to the leaf node (trie)
	 */
	
	public static String encode(HuffTree<Character> tree, String codes) {
		
		char[] input = codes.toCharArray();
		String output = "";
		
		for(int i=0; i<input.length; i++){
			output = output + encodeRecur(tree.root(), input[i], "") + " ";
		}
	
		return output;
	}

	/*
	 * return the encoded String for each character
	 */
	private static String encodeRecur(HuffBaseNode<Character> tree, char c, String prefix) {
		
		if(tree.isLeaf()){
			if( ((HuffLeafNode<Character>) tree).element().compareTo(c) == 0)
				return prefix;
			else
				return prefix.substring(0, prefix.length()-1);
		}else{
			HuffInternalNode<Character> internalnode = (HuffInternalNode<Character>) tree;
			
			String outleft = encodeRecur(internalnode.left(), c, prefix + "1");
			if(outleft.compareTo(prefix) != 0){
				return outleft;
			}
			String outright = encodeRecur(internalnode.right(), c, prefix + "0");		//assign 0 for right child   
			if(outright.compareTo(prefix) != 0){
				return outright;
			}
			
			//if cant find a character, move up
			return prefix.substring(0, prefix.length()-1);		
		}
	}
	
	/*
	 * follow the decoding String of numbers, move down until reach to the leaf node 
	 * and change the String to the element(character) stored in that leaf node  
	 */
	
	public static String decode(HuffTree<Character> tree, String codes) {
		
		HuffBaseNode<Character> rootnode = tree.root();
		char[] input = codes.toCharArray();
		String output = "";
		
		for(int i =0; i<input.length; i++){
		    if(input[i] == '1'){
		    	HuffInternalNode<Character> internalnode = (HuffInternalNode<Character>) rootnode;
		    	rootnode = internalnode.left();
		    	
			}else{	//input[i] == '0'
				HuffInternalNode<Character> internalnode = (HuffInternalNode<Character>) rootnode;
		    	rootnode = internalnode.right();
			}
		    if(rootnode.isLeaf()){
		    	HuffLeafNode<Character> leafnode = (HuffLeafNode<Character>) rootnode;
		    	output = output + leafnode.element();	
		    	rootnode = tree.root();
		    }
		}
		
		return output;
	}
	
	
	/*
	 * show all nodes of huffTree
	 * - each nodes' stored character, weight(freq), encoded String
	 */

	public static void show(HuffBaseNode<Character> tree, String prefix) {
		
		HuffBaseNode<Character> rootnode = tree;
			//HuffBaseNode<Character> rootnode = tree.root();
		char[] character = new char[100];
		int i = 0;
	
		//step1_ extract all characters in Hufftree
		while(!rootnode.isLeaf()){
			HuffBaseNode<Character> left = ((HuffInternalNode<Character>)rootnode).left();
			HuffBaseNode<Character> right =((HuffInternalNode<Character>)rootnode).right();
			if(!left.isLeaf() && !right.isLeaf()) {
				HuffInternalNode<Character> leftnode = (HuffInternalNode<Character>) left;
				HuffInternalNode<Character> rightnode  = (HuffInternalNode<Character>) right;
				if(leftnode.left().isLeaf() && leftnode.right().isLeaf()){
					HuffLeafNode<Character>	leftofleft = (HuffLeafNode<Character>) leftnode.left();
					HuffLeafNode<Character> rightofleft = (HuffLeafNode<Character>) leftnode.right();
					character[i++] = leftofleft.element();
					character[i++] = rightofleft.element();
					rootnode = right;
				}else{	//rightnode.left().isLeaf() && rightnode.right().isLeaf()
					HuffLeafNode<Character>	leftofright = (HuffLeafNode<Character>) rightnode.left();
					HuffLeafNode<Character> rightofright = (HuffLeafNode<Character>) rightnode.right();
					character[i++] = leftofright.element();
					character[i++] = rightofright.element();
					rootnode = left;
				}
				
			}else if( !(left.isLeaf() && right.isLeaf()) ){
				if(left.isLeaf()){
					HuffLeafNode<Character>	leftnode = (HuffLeafNode<Character>) left;
					character[i++] = leftnode.element();
					rootnode = right;
				}else{	//right.isLeaf()	
					HuffLeafNode<Character> rightnode = (HuffLeafNode<Character>) right;
					character[i++] = rightnode.element();
					rootnode = left;
				}
			}else{	//left.isLeaf() && right.isLeaf()	
				HuffLeafNode<Character> leftnode = (HuffLeafNode<Character>) left; 
				HuffLeafNode<Character> rightnode = (HuffLeafNode<Character>) right; 
				character[i++] = leftnode.element();
				character[i++] = rightnode.element();
				rootnode = left;
			}
		}
		
		//step2_ sort the array of characters (in alphabetical order)
		Arrays.sort(character);		//***this sorting also sorts the empty spaces in array
								
		//step3_ encode(find bits), decode(find freq using bits) and print (character freq bits)
		for(int j=100-i; j<character.length; j++){	//***range because of empty spaces also sorted above
			String bits = encodeRecur(tree, character[j], prefix);	//corresponding bits
			char[] bitsarr = bits.toCharArray();
			int freq = 0;
			
			HuffInternalNode<Character> rootnode2 = (HuffInternalNode<Character>) tree;
			
			//from using freq, find weights for each character			
			for(int k = 0; k<bitsarr.length; k++){
				if(bitsarr[k] == '1'){	//move left
					HuffBaseNode<Character> left = rootnode2.left();
					if(left.isLeaf()){
						HuffLeafNode<Character> leftnode = (HuffLeafNode<Character>) left;
						freq = leftnode.weight();
					}else{	//if leftnode is an internal node 
						rootnode2 = (HuffInternalNode<Character>) left;
					}
					
				}else{	//bitsarr[k] == 0  move right
					HuffBaseNode<Character> right = rootnode2.right();
					if(right.isLeaf()){
						HuffLeafNode<Character> rightnode = (HuffLeafNode<Character>) right;
						freq = rightnode.weight();
					}else{	//if rightnode is an internal node 
						rootnode2 = (HuffInternalNode<Character>) right;
					}
				}
			}
			
			System.out.println(character[j] + " " + freq + " " + bits );
		}
	
		return;
	}
	
	
}	//end of main class -------------------------------------------------------------------------------------------------
	


	
