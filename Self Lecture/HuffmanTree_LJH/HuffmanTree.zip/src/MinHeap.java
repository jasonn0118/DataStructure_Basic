
	/** Min-heap implementation */
	//heap inplementation using array 
	
public class MinHeap<E extends Comparable<? super E>> {
			
	//E = HuffTree<Character>
	private E[] Heap; // Pointer to the heap array
	private int size; // Maximum size of the heap
	private int n; // Number of things in heap

	//constructor 
	public MinHeap(E[] h, int num, int max) {
		Heap = h;
		n = num;
		size = max;		// set the maximum size of the heap array 
		buildheap();
	}

	/** Return current size of the heap */
	public int heapsize() {
		return n;
	}

	// Is pos a leaf position? 
	private boolean isLeaf(int pos) {
		// return (pos >= n / 2) && (pos < n); 
		return (n/2 <= pos) && (pos < n);	//leaf node position 
	}

	// Return position for left child of pos
	private int leftchild(int pos) {
		assert pos < n / 2 : "Position has no left child";
		return 2 * pos + 1;
	}

	// Return position for parent 
	private int parent(int pos) {
		assert pos > 0 : "Position has no parent";
		return (pos - 1) / 2;
	}

	/** Heapify contents of Heap */
	private void buildheap() {
		for (int i = n / 2 - 1; i >= 0; i--)	//do the siftdown process only for internal nodes 
			siftdown(i);						
	}
	
	/** Put element in its correct place */
	//siftdown: making heap -> the smaller, the upper position 
	private void siftdown(int pos) {
		assert (pos >= 0) && (pos < n) : "Illegal heap position";
		
		while (!isLeaf(pos)) {	
			int j = leftchild(pos);		//find the left child position 
			
			// j is now index of child with smaller value 
			if ((j < (n - 1)) && (Heap[j].compareTo(Heap[j + 1]) > 0))	j++;	
			
			if (Heap[pos].compareTo(Heap[j]) <= 0) return;	
			
			DSutil.swap(Heap, pos, j);	
			pos = j; 	// Move down (repeat the above process from the beginning)
		}
	}

	/** Insert into heap */ 	 
	//must maintain heap property after insertion 
	public void insert(E val) {
		assert n < size : "Heap is full";		
		int curr = n++;							//store current position and count up
		
		Heap[curr] = val; 	// ***Start at end of heap
		
		// Now sift up until curr's parent's key > curr's key
		while ((curr != 0) && (Heap[curr].compareTo(Heap[parent(curr)]) < 0)) {	
			DSutil.swap(Heap, curr, parent(curr));	//if parent is bigger, swap(minHeap) 
			curr = parent(curr);					//move up 
		}
	}

	
	// Remove minimum value and return it 
	public E removemin() { 
		
		assert n > 0 : "Removing from empty heap";	
		DSutil.swap(Heap, 0, --n); // Swap minimum with last value (also decrease the # of elements)
		
		if (n != 0) 	 
			siftdown(0); // Put new root val of heap into the correct place (for n-1 nodes)
		
		return Heap[n];		//return the removed value (HuffTree)
	}
}


