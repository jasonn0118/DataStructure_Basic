
import java.util.*;
import java.math.*;


/** A bunch of utility functions. */
class DSutil<E> {

	public static void swap(int[] A, int p1, int p2) {
		int temp = A[p1];
		A[p1] = A[p2];
		A[p2] = temp;
	}
	
	public static <E> void swap(E[] A, int p1, int p2) {
		E temp = A[p1];
		A[p1] = A[p2];
		A[p2] = temp;
	}

	static private Random value = new Random(); // Hold the Random class object

	static int random(int n) {
		return Math.abs(value.nextInt()) % n;
	}
	
	// Randomly permute the (int)values of array "A"
	static void permute(int[] A) {
		for (int i = A.length; i > 0; i--) // for each i
			swap(A, i - 1, DSutil.random(i)); // swap A[i-1] with a random element     
	}  

	/** Randomly permute the values in array A */
	static <E> void permute(E[] A) {
		for (int i = A.length; i > 0; i--) 		// for each i
			swap(A, i - 1, DSutil.random(i)); 	// swap A[i-1] with a random element
	} 

	
}
