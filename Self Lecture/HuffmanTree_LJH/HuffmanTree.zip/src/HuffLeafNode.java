
/** Huffman tree node: Leaf class */
class HuffLeafNode<E> implements HuffBaseNode<E> {
	private E element; 		// Element for this node
	private int weight; 	// Weight for this node

	public HuffLeafNode(E el, int wt) {
		element = el;
		weight = wt;
	}

	public E element() {
		return element;
	}

	public int weight() {
		return weight;
	}

	public boolean isLeaf() {
		return true;
	}
}
