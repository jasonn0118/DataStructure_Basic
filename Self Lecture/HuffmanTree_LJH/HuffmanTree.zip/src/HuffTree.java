
/** A Huffman coding tree */
class HuffTree<E> implements Comparable<HuffTree<E>> {
	
	private HuffBaseNode<E> root;	 // Root of the tree
	
		//for leaf node
	public HuffTree(E el, int wt) {					
		root = new HuffLeafNode<E>(el, wt);
	}
		//for internal node
	public HuffTree(HuffBaseNode<E> l, HuffBaseNode<E> r, int wt) {
		root = new HuffInternalNode<E>(l, r, wt);	
	}

	public HuffBaseNode<E> root() {
		return root;
	}

	public int weight() {
		return root.weight();
	}
	
	/** if current weight is bigger than root, then -1 ( < 0 )*/			
	public int compareTo(HuffTree<E> node) {
		if (root.weight() < node.weight())
			return -1;
		else if (root.weight() == node.weight())
			return 0;
		else
			return 1;
	}
}