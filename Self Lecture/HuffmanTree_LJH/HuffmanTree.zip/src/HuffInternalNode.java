

/** Huffman tree node: Internal class */
class HuffInternalNode<E> implements HuffBaseNode<E> {
	private int weight;            // Weight (sum of children)
	private HuffBaseNode<E> left;  // Pointer to left child
	private HuffBaseNode<E> right; // Pointer to right child
	
	public HuffInternalNode(HuffBaseNode<E> l, HuffBaseNode<E> r, int wt) { 
		left = l; 
		right = r; 
		weight = wt; 
	}

	public HuffBaseNode<E> left() { 
		return left; 
	}

	public HuffBaseNode<E> right() { 
		return right; 
	}
	
	public int weight() { 
		return weight; 
	}

	public boolean isLeaf() { 
		return false; 
	}
}