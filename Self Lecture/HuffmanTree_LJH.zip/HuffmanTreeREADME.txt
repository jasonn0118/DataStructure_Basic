README

encode() : encodes (a) character(s) into (a) bit(s)
decode() : decodes (a) bits into character(s)
show() : print all characters in huffman tree and corresponding frequency with encoded bits

execute HuffmanTree_LJH.jar by typing > java -jar ./HuffmanTree_LJH.jar



