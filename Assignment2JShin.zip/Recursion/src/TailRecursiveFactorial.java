/**
 * Compute factorial using tail recursion
 * 
 * @author mhrybyk
 * @author Jeamin Shin
 * 
 */
public class TailRecursiveFactorial implements SequenceInterface {
	private String name;
	private int numberOfCalls = 0; // counter to keep number of recursive calls

	// set the name of the sequence
	public TailRecursiveFactorial(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;

	}

	@Override
	public void resetNumberOfCalls() {
		numberOfCalls = 0;

	}

	@Override
	public int getNumberOfCalls() {
		return numberOfCalls;
	}

	/**
	 * The tail recursive version of factorial.
	 * 
	 * @param n The number to compute factorial of.
	 * @return n factorial.
	 */
	public long compute(long n) {

		//call tail recursive function.
		return subCompute(1, n);

	}

	private long subCompute(long num, long count) {
		//check count.
		numberOfCalls++;
		
		//if count is less than 0. There is no value.
		if (count < 0)
			return 0;
		//if count is 0, it is only 1 value on Factorial.
		else if (count == 0)
			return 1;
		//if count is 1, it is 1 as well.
		else if (count == 1)
			return num;
		//if count is bigger than 1, it recalls subCoumpute recursively. so that multiply before recursion. 
		else {
			return subCompute(num * count, count - 1);
		}
	}

}
