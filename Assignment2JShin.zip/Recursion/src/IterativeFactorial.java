/**
 * Simple iterative factorial
 * 
 * @author mhrybyk
 * @author Jeamin Shin
 *
 */
public class IterativeFactorial implements SequenceInterface {

	private String name;
	private int numberOfCalls = 0;

	// set the name of the sequence
	public IterativeFactorial(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;

	}

	/**
	 * Compute the factorial using iteration
	 * 
	 * @param n
	 * @return factorial
	 */
	@Override
	public long compute(long n) {
		//simple iterative function.
		//set result value as 1. not 0.
		long result = 1;
		
		//for loop for the factorial.
		for (long i = 1; i <= n; i++) {
			result *= i;
		}
		//counting.
		numberOfCalls++;
		//if result is 0 just in case, return value will be 1.
		if (result == 0) {
			return result=1;
		}
		//Otherwise returns factorial value.
		else
			return result;
	}

	@Override
	public void resetNumberOfCalls() {
		numberOfCalls = 0;

	}

	@Override
	public int getNumberOfCalls() {
		return numberOfCalls;
	}

}
