
public class Person implements NameInterface {
	String firstName;
	String lastName;
	int age;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public void setName(String firstName, String lastName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setFirst(String firstName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getFirst() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setLast(String lastName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getLast() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void giveLastNameTo(NameInterface aName) {
		// TODO Auto-generated method stub
		
	}
	
	

}
