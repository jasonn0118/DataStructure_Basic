/**
 * @author Frank M. Carrano, Timothy M. Henry
 * @version 5.0
 */
public interface Callable extends Nameable {
	public void come(String petName);
} 
