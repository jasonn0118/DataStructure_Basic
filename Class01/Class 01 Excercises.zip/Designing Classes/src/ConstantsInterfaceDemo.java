/**
 * @author Frank M. Carrano, Timothy M. Henry
 * @version 5.0
 */
public class ConstantsInterfaceDemo implements ConstantsInterface {
	public static void main(String[] args) {
		System.out.println("ConstantsInterfaceDemo");
		System.out.println(FEET_PER_METER);
		System.out.println(ConstantsInterface.MILES_PER_KILOMETER);
	} 
} 
