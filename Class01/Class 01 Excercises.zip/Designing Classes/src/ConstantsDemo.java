/**
 * @author Frank M. Carrano, Timothy M. Henry
 * @version 5.0
 */
public class ConstantsDemo {
	public static void main(String[] args) {
		System.out.println("ConstantsDemo");
		System.out.println(Constants.FEET_PER_METER);
		System.out.println(Constants.MILES_PER_KILOMETER);
	} 
} 
