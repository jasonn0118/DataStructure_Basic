/**
 * @author Frank M. Carrano, Timothy M. Henry
 * @version 5.0
 */
public interface Capable {
	public void hear();

	public void respond();
} 
