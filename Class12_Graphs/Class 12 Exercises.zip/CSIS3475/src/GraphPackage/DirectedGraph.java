package GraphPackage;

import java.util.Iterator;

import DictionaryPackage.*;
import HeapPackage.*;
import QueuePackage.*;
import StackPackage.*;

/**
 * A class that implements the ADT directed graph.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 */
public class DirectedGraph<T extends Comparable<? super T>> implements GraphInterface<T> {
	private DictionaryInterface<T, VertexInterface<T>> vertices;
	private int edgeCount;

	public DirectedGraph() {
		vertices = new ListDictionary<>();
		edgeCount = 0;
	} 



	@Override
	public boolean addVertex(T vertexLabel) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public boolean addEdge(T begin, T end, double edgeWeight) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public boolean addEdge(T begin, T end) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public boolean hasEdge(T begin, T end) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public int getNumberOfVertices() {
		// TODO Auto-generated method stub
		return 0;
	}



	@Override
	public int getNumberOfEdges() {
		// TODO Auto-generated method stub
		return 0;
	}



	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}



	protected void resetVertices() {
		Iterator<VertexInterface<T>> vertexIterator = vertices.getValueIterator();
		while (vertexIterator.hasNext()) {
			VertexInterface<T> nextVertex = vertexIterator.next();
			nextVertex.unvisit();
			nextVertex.setCost(0);
			nextVertex.setPredecessor(null);
		} 
	} 


	
	@Override
	public QueueInterface<T> getBreadthFirstTraversal(T origin) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public QueueInterface<T> getDepthFirstTraversal(T origin) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public StackInterface<T> getTopologicalOrder() {
		// TODO Auto-generated method stub
		return null;
	}



	/**
	 * Find the first vertex that is a terminal. That is, it has ONLY
	 * visited neighbors.
	 * @return
	 */
	protected VertexInterface<T> findTerminal() {
		boolean found = false;
		VertexInterface<T> result = null;

		// search through all of the vertices in the graph.
		
		Iterator<VertexInterface<T>> vertexIterator = vertices.getValueIterator();

		while (!found && vertexIterator.hasNext()) {
			VertexInterface<T> nextVertex = vertexIterator.next();

			// If nextVertex is unvisited AND has only visited neighbors)
			// then we have found our terminal vertex
			
			if (!nextVertex.isVisited()) {
				if (nextVertex.getUnvisitedNeighbor() == null) {
					found = true;
					result = nextVertex;
				} 
			} 
		} 

		return result;
	} 

	@Override
	public int getShortestPath(T begin, T end, StackInterface<T> path) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public double getCheapestPath(T begin, T end, StackInterface<T> path) {
		// TODO Auto-generated method stub
		return 0;
	}

	// Used for testing
	public void displayEdges() {
		System.out.println("DirectedGraph.displayEdges(): Edges exist from the first vertex in each line to the other vertices in the line.");
		System.out.println("(Edge weights are given; weights are zero for unweighted graphs):");
		Iterator<VertexInterface<T>> vertexIterator = vertices.getValueIterator();
		while (vertexIterator.hasNext()) {
			((Vertex<T>) (vertexIterator.next())).display();
		} 
	} 

	private class EntryPQ implements Comparable<EntryPQ> {
		private VertexInterface<T> vertex;
		private VertexInterface<T> previousVertex;
		private double cost; // cost to nextVertex

		private EntryPQ(VertexInterface<T> vertex, double cost, VertexInterface<T> previousVertex) {
			this.vertex = vertex;
			this.previousVertex = previousVertex;
			this.cost = cost;
		} 

		public VertexInterface<T> getVertex() {
			return vertex;
		} 

		public VertexInterface<T> getPredecessor() {
			return previousVertex;
		} 

		public double getCost() {
			return cost;
		} 

		public int compareTo(EntryPQ otherEntry) {
			// Using opposite of reality since our priority queue uses a maxHeap;
			// could revise using a minheap
			return (int) Math.signum(otherEntry.cost - cost);
		} 

		public String toString() {
			return vertex.toString() + " " + cost;
		} 
	} 
} 
