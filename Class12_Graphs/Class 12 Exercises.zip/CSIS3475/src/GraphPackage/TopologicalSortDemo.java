package GraphPackage;

import QueuePackage.*;
import StackPackage.*;

/**
 * A driver that demonstrates the class CompletedDirectedGraph and an unweighted graph
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 */
public class TopologicalSortDemo {
	private static CompletedDirectedGraph<String> myGraph = new CompletedDirectedGraph<>();
//	private static CompletedDirectedGraph<String> myGraph = new DirectedGraph<>();

	private static final String CS1 = "CS1";
	private static final String CS2 = "CS2";
	private static final String CS3 = "CS3";
	private static final String CS4 = "CS4";
	private static final String CS5 = "CS5";
	private static final String CS6 = "CS6";
	private static final String CS7 = "CS7";
	private static final String CS8 = "CS8";
	private static final String CS9 = "CS9";
	private static final String CS10 = "CS10";

	public static void main(String[] args) {

		System.out.println("Testing topological sort of directed, unweighted graph in Figure 29-8:");
		
		setGraph();
		checkVertexAndEdgeCount(10, 11);  // should be 10 vertices, 11 edges
		testEdges();
		testTopSort(); 

		System.out.println("Done.");
	} 

	public static void setGraph() {
		setVertices();
		setEdges();
	} 

	public static void checkVertexAndEdgeCount(int numberOfVertices, int numberOfEdges) {
		System.out.println(
				"\nNumber of vertices = " + myGraph.getNumberOfVertices() + " (should be " + numberOfVertices + ")");
		System.out.println("Number of edges = " + myGraph.getNumberOfEdges() + " (should be " + numberOfEdges + ")");
	} 

	public static void testEdges() {
		// Check existing edges
		boolean ok = true;
		ok = checkEdge(CS1, CS2, ok);
		ok = checkEdge(CS2, CS3, ok);
		ok = checkEdge(CS2, CS4, ok);
		ok = checkEdge(CS2, CS5, ok);
		ok = checkEdge(CS4, CS6, ok);
		ok = checkEdge(CS4, CS7, ok);
		ok = checkEdge(CS5, CS10, ok);
		ok = checkEdge(CS6, CS8, ok);
		ok = checkEdge(CS7, CS8, ok);
		ok = checkEdge(CS7, CS9, ok);
		ok = checkEdge(CS9, CS10, ok);

		// Check some non-existing edges
		ok = checkNoEdge(CS1, CS3, ok);
		ok = checkNoEdge(CS1, CS5, ok);
		ok = checkNoEdge(CS4, CS10, ok);

		if (ok)
			System.out.println("Edges are OK.");
		myGraph.displayEdges();
	} 

	private static boolean checkEdge(String vertex1, String vertex2, boolean ok) {
		boolean check = ok;
		if (!myGraph.hasEdge(vertex1, vertex2)) {
			System.out.println("hasEdge error " + vertex1 + " " + vertex2);
			check = false;
		} 

		return check;
	} 

	private static boolean checkNoEdge(String vertex1, String vertex2, boolean ok) {
		boolean check = ok;
		if (myGraph.hasEdge(vertex1, vertex2)) {
			System.out.println("hasEdge error " + vertex1 + " " + vertex2);
			check = false;
		} 

		return check;
	} 

	public static void testTopSort() {
		StackInterface<String> sort = myGraph.getTopologicalOrder();
		System.out.println("\n\nTopological order:");
		displayStack(sort);
		System.out.println(" Actual");
		System.out.println("CS1 CS2 CS4 CS7 CS9 CS5 CS10 CS6 CS8 CS3  Expected");
	} 

	public static void setVertices() {
		myGraph.clear();

		myGraph.addVertex(CS1);
		myGraph.addVertex(CS2);
		myGraph.addVertex(CS3);
		myGraph.addVertex(CS4);
		myGraph.addVertex(CS5);
		myGraph.addVertex(CS6);
		myGraph.addVertex(CS7);
		myGraph.addVertex(CS8);
		myGraph.addVertex(CS9);
		myGraph.addVertex(CS10);
	} 

	public static void setEdges() {
		myGraph.addEdge(CS1, CS2);

		myGraph.addEdge(CS2, CS3);
		myGraph.addEdge(CS2, CS4);
		myGraph.addEdge(CS2, CS5);

		myGraph.addEdge(CS4, CS6);
		myGraph.addEdge(CS4, CS7);

		myGraph.addEdge(CS5, CS10);

		myGraph.addEdge(CS6, CS8);

		myGraph.addEdge(CS7, CS8);
		myGraph.addEdge(CS7, CS9);

		myGraph.addEdge(CS9, CS10);
	} 



	public static void displayStack(StackInterface<String> s) {
		while (!s.isEmpty())
			System.out.print(s.pop() + " ");

		assert (s.isEmpty());
	} 

	public static void displayQueue(QueueInterface<String> q) {
		while (!q.isEmpty())
			System.out.print(q.dequeue() + " ");
	} 
} 

/*
Testing topological sort of directed, unweighted graph in Figure 29-8:

Number of vertices = 10 (should be 10)
Number of edges = 11 (should be 11)
Edges are OK.
CompletedDirectedGraph.displayEdges(): Edges exist from the first vertex in each line to the other vertices in the line.
(Edge weights are given; weights are zero for unweighted graphs):
CS1 CS2 0.0 
CS2 CS3 0.0 CS4 0.0 CS5 0.0 
CS3 
CS4 CS6 0.0 CS7 0.0 
CS5 CS10 0.0 
CS6 CS8 0.0 
CS7 CS8 0.0 CS9 0.0 
CS8 
CS9 CS10 0.0 
CS10 


Topological order:
CS1 CS2 CS4 CS7 CS9 CS5 CS10 CS6 CS8 CS3  Actual
CS1 CS2 CS4 CS7 CS9 CS5 CS10 CS6 CS8 CS3  Expected
Done.

*/
