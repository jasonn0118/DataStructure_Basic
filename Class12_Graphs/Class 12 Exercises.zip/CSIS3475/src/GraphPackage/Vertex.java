package GraphPackage;

import java.util.Iterator;
import java.util.NoSuchElementException;

import ListWithIteratorsPackage.*;

/**
 * A class of vertices for a graph.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 */
class Vertex<T> implements VertexInterface<T> {
	private T label;
	private ListWithIteratorInterface<Edge> edgeList; // Edges to neighbors
	private boolean visited; // True if visited
	private VertexInterface<T> previousVertex; // On path to this vertex
	private double cost; // Of path to this vertex

	public Vertex(T vertexLabel) {
		label = vertexLabel;
		edgeList = new CompletedLListWithIterator<>();
//		edgeList = new LListWithIterator<>();
		visited = false;
		previousVertex = null;
		cost = 0;
	} 

	public T getLabel() {
		return label;
	} 

	public boolean hasPredecessor() {
		return previousVertex != null;
	} 

	public void setPredecessor(VertexInterface<T> predecessor) {
		previousVertex = predecessor;
	} 

	public VertexInterface<T> getPredecessor() {
		return previousVertex;
	} 

	public void visit() {
		visited = true;
	} 

	public void unvisit() {
		visited = false;
	} 

	public boolean isVisited() {
		return visited;
	} 

	public double getCost() {
		return cost;
	} 

	public void setCost(double newCost) {
		cost = newCost;
	} 

	public String toString() {
		return label.toString();
	} 
	
	public boolean connect(VertexInterface<T> endVertex, double edgeWeight) {
		boolean result = false;

		if (!this.equals(endVertex)) { // Vertices are distinct
			Iterator<VertexInterface<T>> neighbors = getNeighborIterator();
			boolean duplicateEdge = false;

			while (!duplicateEdge && neighbors.hasNext()) {
				VertexInterface<T> nextNeighbor = neighbors.next();
				if (endVertex.equals(nextNeighbor))
					duplicateEdge = true;
			} 

			// this is a new unique vertex, so add an edge connecting it
			if (!duplicateEdge) {
				edgeList.add(new Edge(endVertex, edgeWeight));
				result = true;
			} 
		} 

		return result;
	} 

	public boolean connect(VertexInterface<T> endVertex) {
		return connect(endVertex, 0);
	} 

	public Iterator<Double> getWeightIterator() {
		return new WeightIterator();
	} 

	private class WeightIterator implements Iterator<Double> {
		private Iterator<Edge> edges;

		private WeightIterator() {
			edges = edgeList.iterator();
		} 

		public boolean hasNext() {
			return edges.hasNext();
		} 

		public Double next() {
			Double edgeWeight = 0.0;
			if (edges.hasNext()) {
				Edge edgeToNextNeighbor = edges.next();
				edgeWeight = edgeToNextNeighbor.getWeight();
			} else
				throw new NoSuchElementException();

			return edgeWeight;
		} 

		public void remove() {
			throw new UnsupportedOperationException();
		} 
	} 

	public Iterator<VertexInterface<T>> getNeighborIterator() {
		return new NeighborIterator();
	} 
	
	private class NeighborIterator implements Iterator<VertexInterface<T>> {
		private Iterator<Edge> edges;

		private NeighborIterator() {
			edges = edgeList.iterator();
		} 

		public boolean hasNext() {
			return edges.hasNext();
		} 

		public VertexInterface<T> next() {
			VertexInterface<T> nextNeighbor = null;

			if (edges.hasNext()) {
				Edge edgeToNextNeighbor = edges.next();
				nextNeighbor = edgeToNextNeighbor.getEndVertex();
			} else
				throw new NoSuchElementException();

			return nextNeighbor;
		} 

		public void remove() {
			throw new UnsupportedOperationException();
		} 
	} 

	public boolean hasNeighbor() {
		return !edgeList.isEmpty();
	} 

	public VertexInterface<T> getUnvisitedNeighbor() {
		VertexInterface<T> result = null;

		Iterator<VertexInterface<T>> neighbors = getNeighborIterator();
		while (neighbors.hasNext() && (result == null)) {
			VertexInterface<T> nextNeighbor = neighbors.next();
			if (!nextNeighbor.isVisited())
				result = nextNeighbor;
		} 

		return result;
	} 

	public boolean equals(Object other) {
		boolean result;

		if ((other == null) || (getClass() != other.getClass()))
			result = false;
		else {
			// The cast is safe within this else clause
			@SuppressWarnings("unchecked")
			Vertex<T> otherVertex = (Vertex<T>) other;
			result = label.equals(otherVertex.label);
		} 

		return result;
	} 


	/**
	 * Edge in a graph. An edge connects two vertices. We will
	 * just keep the vertex at the end.
	 * 
	 * Weight is also kept. 
	 */
	protected class Edge implements Comparable<Edge> {
		private VertexInterface<T> vertex; // Vertex at end of edge
		private double weight;

		protected Edge(VertexInterface<T> endVertex, double edgeWeight) {
			vertex = endVertex;
			weight = edgeWeight;
		} 

		protected Edge(VertexInterface<T> endVertex) {
			vertex = endVertex;
			weight = 0;
		} 

		protected VertexInterface<T> getEndVertex() {
			return vertex;
		} 

		protected double getWeight() {
			return weight;
		} 

		@Override
		public int compareTo(Edge other) {

			// so we can reuse classes that support ListInterface

			throw new java.lang.UnsupportedOperationException("Comparison not supported.");
		}
	} 

	public void display() // For testing
	{
		System.out.print(label + " ");
		Iterator<VertexInterface<T>> i = getNeighborIterator();
		Iterator<Double> w = getWeightIterator();

		while (i.hasNext()) {
			Vertex<T> v = (Vertex<T>) i.next();
			System.out.print(v + " " + w.next() + " ");
		} 

		System.out.println();
	} 
} 
