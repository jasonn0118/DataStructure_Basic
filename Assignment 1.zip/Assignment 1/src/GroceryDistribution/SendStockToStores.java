package GroceryDistribution;

import java.io.*;
import java.util.Scanner;
import QueuePackage.*;

/**
 * 
 * @author YOUR NAME HERE
 *
 */
public class SendStockToStores {

	public static void main(String[] args) {

		String fileName = "GroceryItems.csv";
		Scanner textReader = null;

		// your code here
		
	}

}

