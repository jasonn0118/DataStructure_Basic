/**
 * 
 */
package GroceryDistribution;

import StackPackage.*;


/**
 * @author YOUR NAME HERE
 *
 */
public class Truck<T> {

	
}
