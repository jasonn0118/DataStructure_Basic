package GroceryDistribution;

import java.io.*;
import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter.DEFAULT;

import QueuePackage.*;
import StackPackage.ArrayStack;
import StackPackage.LinkedStack;
import StackPackage.StackInterface;
import StackPackage.VectorStack;

/**
 * 
 * @author Jeamin Shin
 *
 */
public class SendStockToStores {

	public static void main(String[] args) {

		String fileName = "GroceryItems.csv";
		Scanner textReader = null;

		// your code here

		// create file variable.
		File myFile = new File(fileName);
		String[] myLine = null;
		Truck truckFromToronto = new Truck<>("Calgary", "Warehouse");
		Truck trucFromCalgary = new Truck<>("Toronto", "Warehouse");
		Truck trucFromCalifornia = new Truck<>("California", "Warehouse");
		QueueInterface<GroceryItem> wareHouse = new ArrayQueue<GroceryItem>();
//		QueueInterface<GroceryItem> wareHouse = new LinkedQueue<GroceryItem>();
//		QueueInterface<GroceryItem> wareHouse = new TwoPartCircularLinkedQueue<GroceryItem>();

		int index = 0;

		try {
			textReader = new Scanner(myFile);
			while (textReader.hasNext()) {
				String tempString = textReader.nextLine();
				myLine = tempString.split(",");
				switch (myLine[3]) {
				case "Toronto":
//				index++;
//				System.out.println("Toronto"+"count: "+index);
					truckFromToronto.addGroceryItem(
							new GroceryItem(myLine[0], Integer.parseInt(myLine[1]), myLine[2], myLine[3]));
					break;
				case "Calgary":
					trucFromCalgary.addGroceryItem(
							new GroceryItem(myLine[0], Integer.parseInt(myLine[1]), myLine[2], myLine[3]));
					break;
				case "California":
					trucFromCalifornia.addGroceryItem(
							new GroceryItem(myLine[0], Integer.parseInt(myLine[1]), myLine[2], myLine[3]));
					break;
				default:
					break;
				}

			}
			
			for (int i = 0; i < truckFromToronto.getArrayOfGroceryItems().length; i++) {
//				System.out.println(i);
				wareHouse.enqueue(truckFromToronto.popGroceryItems());
			}
			System.out.println(wareHouse.size());
//			System.out.println("Toronto size: " + );
//			for (int i = 0; i < trucFromCalgary.getArrayOfGroceryItems().length; i++) {
//				System.out.println(trucFromCalgary.popGroceryItems().getItemName());
//				wareHouse.enqueue(trucFromCalgary.popGroceryItems());
//			}
//			System.out.println("Calgary size: "+trucFromCalgary.sizeOfItems());
//			for (int i = 0; i < trucFromCalifornia.getArrayOfGroceryItems().length; i++) {
//				System.out.println(trucFromCalifornia.popGroceryItems().getItemName());
//				wareHouse.enqueue(trucFromCalifornia.popGroceryItems());
//			}

		}

		catch (IOException e) {
			e.getMessage();
		}

	}
//
//	static <T> void displayStack(StackInterface<T> stack) {
//		T[] stackEntries = stack.toArray();
//		displayStack(stackEntries, stack.size());
//	}
//
//	static <T> void displayStack(Stack<T> stack) {
//		@SuppressWarnings("unchecked")
//		T[] stackEntries = (T[]) stack.toArray();
//
//		displayStack(stackEntries, stack.size());
//	}
//
//	static <T> void displayStack(T[] stack, int size) {
//		System.out.println("GloceryItem[ ");
//		for (int index = 0; index < size; index++)
//			System.out.print(" " + stack[index]);
//		System.out.println();
//
//	}

}
