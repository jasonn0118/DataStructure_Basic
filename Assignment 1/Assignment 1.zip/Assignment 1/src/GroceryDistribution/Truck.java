/**
 * 
 */
package GroceryDistribution;

import StackPackage.*;

/**
 * @author Jeamin Shin
 *
 */
public class Truck<T> {

	private String destination;
	private String source;
	private StackInterface<GroceryItem> temp = new ArrayStack<GroceryItem>();
//	private StackInterface<GroceryItem> temp = new LinkedStack<GroceryItem>();
//	private StackInterface<GroceryItem> temp = new VectorStack<GroceryItem>();
	public Truck() {
		
		this.destination ="";
		this.source = "";
	
	}
	
	public Truck(String des, String sour) {
	
		this.destination = des;
		this.source = sour;
	}
	
	public void addGroceryItem(GroceryItem gr) {
		this.temp.push(gr);
	}
	public GroceryItem popGroceryItems() {
		return this.temp.pop();
	}
	
//	public  StackInterface<GroceryItem> getStack() {
//		return this.temp;
//	}
	
	public T[] getArrayOfGroceryItems() {
		return (T[]) this.temp.toArray();
	}
	public int sizeOfItems() {
		return this.temp.size();
	}
	

	
	
	public void displayItems() {
		System.out.println(this.temp.peek().toString());
	}
	
	
	
}
