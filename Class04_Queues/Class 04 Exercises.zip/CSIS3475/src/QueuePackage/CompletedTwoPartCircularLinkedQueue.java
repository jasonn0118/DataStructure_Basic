package QueuePackage;

/**
 * A class that implements the ADT queue by using a two-part circular chain of
 * linked nodes.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 */
public final class CompletedTwoPartCircularLinkedQueue<T> implements QueueInterface<T> {
	private Node<T> queueNode; // References first node in queue
	private Node<T> freeNode; // References node after back of queue, chain of unallocated nodes
	int numberOfEntries;

	public CompletedTwoPartCircularLinkedQueue() {
		freeNode = new Node<>(null, null);
		freeNode.setNextNode(freeNode); // links to itself
		queueNode = freeNode; // queueNode will be at the top of the chain
		numberOfEntries = 0;
	}

	public void enqueue(T newEntry) {
		freeNode.setData(newEntry);

//		System.out.println();
//		System.out.println("freeNode start of enqueue - " + freeNode.getData() + " Next: " + freeNode.getNextNode().getData());

		if (isNewNodeNeeded()) {
			// Allocate a new node (null) and insert it after the node that
			// freeNode references

//			System.out.println("Need a new node: set to null and next to " + freeNode.getNextNode().getData());

			Node<T> newNode = new Node<>(null, freeNode.getNextNode());
			freeNode.setNextNode(newNode);

//			System.out.println("freeNode next: set to the new node just created");
		}

//		System.out.println("freeNode before reset  - " + freeNode.getData() + " Next: " + freeNode.getNextNode().getData());

		// we have a null as next node, so set free node to it.
		freeNode = freeNode.getNextNode();
		numberOfEntries++;
//		System.out.println("freeNode end of enqueue - " + freeNode.getData() + " Next: " + freeNode.getNextNode().getData());	
	}

	/**
	 * In a two part circular chain, check if the node at the top of the queue is
	 * the same as the free node's next in the chain.
	 * 
	 * @return
	 */
	private boolean isNewNodeNeeded() {
		return queueNode == freeNode.getNextNode();
	}

	public T getFront() {

		if (isEmpty())
			throw new EmptyQueueException();
		else
			return queueNode.getData();
	}

	public T dequeue() {

		// get the front of the queue
		T front = getFront();

		// clear the data, and set the front to the next node
		queueNode.setData(null);
		queueNode = queueNode.getNextNode();

		numberOfEntries--;
		return front;
	}

	public boolean isEmpty() {
		return queueNode == freeNode;
	}

	public void clear() {
		while (!isEmpty())
			dequeue();
	}

	@Override
	public int size() {
		return numberOfEntries;
	}

	@Override
	public T[] toArray() {
		// create a new array
		@SuppressWarnings("unchecked")
		T[] items = (T[]) new Object[size()];

		// walk along the chain, copying the data to the array each iteration
		// note that the end of the queue is at freeNode
		int index = 0;
		for (Node<T> node = queueNode; node != freeNode; node = node.getNextNode()) {
			items[index] = node.getData();
			index++;
		}

		// ok to return an array with no items
		return items;
	}

}
