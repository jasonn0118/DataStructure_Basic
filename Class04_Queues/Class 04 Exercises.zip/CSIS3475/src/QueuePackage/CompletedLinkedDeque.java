package QueuePackage;
/**
 * A class that implements the ADT deque by using a doubly linked chain of
 * nodes.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 */
public class CompletedLinkedDeque<T> implements DequeInterface<T> {
	private DoublyLinkedNode<T> firstNode; // References node at front of deque
	private DoublyLinkedNode<T> lastNode; // References node at back of deque
	private int numberOfEntries;

	public CompletedLinkedDeque() {
		firstNode = null;
		lastNode = null;
		numberOfEntries = 0;
	}

	public void addToBack(T newEntry) {
		
		// set the previous node for the entry, and next is null
		
		DoublyLinkedNode<T> newNode = new DoublyLinkedNode<>(lastNode, newEntry, null);

		// if both are null, just need to set the first one
		// otherwise lastNode's next is set to null, so set it to this one.
		if (isEmpty())
			firstNode = newNode;
		else
			lastNode.setNextNode(newNode);

		// finally make the new node the last node, now that all the links are fixed up
		
		lastNode = newNode;
		numberOfEntries++;
	} 

	public void addToFront(T newEntry) {
		
		// instead, previous node is null, and next is the start of the list
		
		DoublyLinkedNode<T> newNode = new DoublyLinkedNode<>(null, newEntry, firstNode);

		// if first and last are null, set last to the new node
		// otherwise set the previous node for for the start of the list to this one
		
		if (isEmpty())
			lastNode = newNode;
		else
			firstNode.setPreviousNode(newNode);

		// links are all fixed up, make the first node this one
		
		firstNode = newNode;
		
		numberOfEntries++;
	} 

	public T getBack() {
		if (isEmpty())
			throw new EmptyQueueException();
		else
			return lastNode.getData();
	} 

	public T getFront() {
		if (isEmpty())
			throw new EmptyQueueException();
		else
			return firstNode.getData();
	} 

	public T removeFront() {
		
		T front = getFront(); 
		
		// skip around node, resetting first node to
		//   the next on the chain
		// make sure the previous node is also set to null
		
		firstNode = firstNode.getNextNode();

		if (firstNode == null)
			lastNode = null;
		else
			firstNode.setPreviousNode(null);
		
		numberOfEntries--;

		return front;
	} 

	public T removeBack() {
		T back = getBack(); 
		
		// move the last node to the one before
		//  then set its next to null
		lastNode = lastNode.getPreviousNode();

		if (lastNode == null)
			firstNode = null;
		else
			lastNode.setNextNode(null);

		numberOfEntries--;
		
		return back;
	} 

	public void clear() {
		firstNode = null;
		lastNode = null;
		numberOfEntries = 0;
	}

	public boolean isEmpty() {
		return (firstNode == null) && (lastNode == null);
	} 


	@Override
	public int size() {
		return numberOfEntries;
	}

	@Override
	public T[] toArray() {
		// create a new array 
		@SuppressWarnings("unchecked")
		T[] items = (T[]) new Object[size()];

		// ok to return an empty array
		
		if(isEmpty())
			return items;
		// walk along the chain, copying the data to the array each iteration

		int index = 0;
		for (Node<T> node = firstNode; node != null; node = node.getNextNode()) {
			items[index] = node.getData();
			index++;
		}
		return items;
	}
} 
