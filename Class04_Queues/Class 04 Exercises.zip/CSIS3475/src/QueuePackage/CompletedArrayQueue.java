package QueuePackage;

/**
 * A class that implements the ADT queue by using an expandable circular array
 * with one unused location after the back of the queue.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 * 
 * @author mhrybyk
 * 
 *         Modified to add nextIndex(), making the calculation of the index with
 *         wraparound easier
 * 
 *         Added copyToArray() as a common method used by ensureCapacity() and
 *         toArray()
 */
public final class CompletedArrayQueue<T> implements QueueInterface<T> {
	private T[] queue; // Circular array of queue entries and one unused location
	private int frontIndex; // Index of front entry
	private int backIndex; // Index of back entry

	private static final int DEFAULT_CAPACITY = 3;
	private static final int MAX_CAPACITY = 10000;

	public CompletedArrayQueue() {
		this(DEFAULT_CAPACITY);
	}

	public CompletedArrayQueue(int initialCapacity) {

		checkCapacity(initialCapacity);

		// The cast is safe because the new array contains null entries
		@SuppressWarnings("unchecked")

		// always leave space for the next entry

		T[] tempQueue = (T[]) new Object[initialCapacity + 1];
		queue = tempQueue;
		frontIndex = 0;
		backIndex = initialCapacity;

	}

	/**
	 * Since this is a circular queue, incrementing the index will always be modulo
	 * queue length to ensure wrap around.
	 * 
	 * Let's encode this here to make things more readable
	 * 
	 * @param index current index in the circular queue
	 * @return the next index in the circular queue
	 */
	private int nextIndex(int index) {
		return (index + 1) % queue.length;
	}

	public void enqueue(T newEntry) {
		ensureCapacity();

		// increment back index, then set new entry to its slot
		backIndex = nextIndex(backIndex);
		queue[backIndex] = newEntry;
//		System.out.println("Enqueue at " + backIndex + ": " + newEntry.toString());
	}

	public T getFront() {
		if (isEmpty())
			throw new EmptyQueueException();
		else
			return queue[frontIndex];
	}

	public T dequeue() {

		if (isEmpty())
			throw new EmptyQueueException();
		
		// get the front of the queue
		T front = queue[frontIndex];
//			System.out.println("Dequeue at " + frontIndex + ": " + front);

		// set the current front to null, clearing it
		queue[frontIndex] = null;

		// increment the front
		frontIndex = nextIndex(frontIndex);
		return front;

	}

	public boolean isEmpty() {
		// if we increment backIndex and get frontIndex, we
		// have wrapped around, and so the queue is empty
		return frontIndex == nextIndex(backIndex);
	}

	public void clear() {
		// sets all allocated entries to null
		// this could also be done using dequeue()

		if (!isEmpty()) {
			// iterate through the queue
			for (int index = frontIndex; index != nextIndex(backIndex); index = nextIndex(index)) {
				queue[index] = null;
			}
		}

		// reset front and back indices
		frontIndex = 0;
		backIndex = queue.length - 1;
	} // end clear

	@Override
	public int size() {

		// increment the back and subtract the front
		// If they are the same, size is zero
		// if difference is positive, this is the exact size
		// as back is behind front
		// if it is negative, back is before front, so adjust
		// by array size
		int size = nextIndex(backIndex) - frontIndex;
		if (size < 0)
			size = size + queue.length;

		return size;
	}

	@Override
	public T[] toArray() {
		@SuppressWarnings("unchecked")
		T[] items = (T[]) new Object[size()];

		// copy the queue contents to the output array
		copyToArray(items);
		return items;
	}

	/**
	 * Copy the items in the queue over to an array Array must be equal or larger in
	 * size than queue
	 * 
	 * @param array destination array for copy.
	 */
	private void copyToArray(T[] array) {
		// should be assertions
		if (array == null)
			return;

		if (array.length < size())
			return;

		// iterate through the queue and copy items over to the array
		int tempIndex = 0;
		for (int currentIndex = frontIndex; currentIndex != nextIndex(backIndex); currentIndex = nextIndex(
				currentIndex)) {
			array[tempIndex] = queue[currentIndex];
			tempIndex++;
		}
	}

	/**
	 * Throws an exception if the client requests a capacity that is too large.
	 * 
	 * @param capacity
	 */
	private void checkCapacity(int capacity) {
		if (capacity > MAX_CAPACITY)
			throw new IllegalStateException(
					"Attempt to create a queue " + "whose capacity exceeds " + "allowed maximum.");
	}

	/**
	 * Doubles the size of the array queue if it is full.
	 */
	private void ensureCapacity() {

		// first check to see if array is full which
		// means we need an additional slot besides the one
		// we need to fill (hence backIndex + 1)

		if (frontIndex == nextIndex(backIndex + 1)) {
			// double size of array
			int oldSize = queue.length;
			int newSize = 2 * oldSize;
			checkCapacity(newSize);

			// create the larger queue
			// The cast is safe because the new array contains null entries
			@SuppressWarnings("unchecked")
			T[] tempQueue = (T[]) new Object[newSize];

			// copy the queue contents to the the new array.

			copyToArray(tempQueue);
			queue = tempQueue; // set the queue to the new array

			// reset front and back indices. front starts at zero again
			frontIndex = 0;
			// we wanted two slots back from end, so reset this
			backIndex = oldSize - 2;

		}
	}
}
