package QueueDemoPackage;

/**
 * An immutable class that represents a purchase of a number of shares of stock.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 */
public class StockPurchaseUsingDeque {
	private int shares;
	private double cost;

	public StockPurchaseUsingDeque(int numberOfShares, double costPerShare) {
		shares = numberOfShares;
		cost = costPerShare;
	} 

	public int getNumberOfShares() {
		return shares;
	} 

	public double getCostPerShare() {
		return cost;
	} 

	public double getValue() {
		return shares * cost;
	} 
	
	@Override
	public String toString() {
		return "Shares " + shares + " Cost per share " + cost;
	}
} 