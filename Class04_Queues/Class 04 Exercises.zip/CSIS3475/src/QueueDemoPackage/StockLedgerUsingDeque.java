package QueueDemoPackage;

import QueuePackage.*;

/**
 * A class that records the purchase and sale of stocks, and provides the
 * capital gain or loss.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 */
public class StockLedgerUsingDeque {
	private DequeInterface<StockPurchaseUsingDeque> ledger;

	public StockLedgerUsingDeque() {
		ledger = new CompletedLinkedDeque<>();
	}

	/**
	 * Records a stock purchase in this ledger.
	 * 
	 * @param sharesBought  The number of shares purchased.
	 * @param pricePerShare The price per share.
	 */
	public void buy(int sharesBought, double pricePerShare) {
		StockPurchaseUsingDeque purchase = new StockPurchaseUsingDeque(sharesBought, pricePerShare);
		ledger.addToBack(purchase);
	}

	/**
	 * Removes from this ledger any shares that were sold and computes the capital
	 * gain or loss.
	 * 
	 * @param sharesSold    The number of shares sold.
	 * @param pricePerShare The price per share.
	 * @return The capital gain (loss).
	 */
	public double sell(int sharesSold, double pricePerShare) {
		double saleAmount = sharesSold * pricePerShare;
		double totalCost = 0;

		while (sharesSold > 0) {
			StockPurchaseUsingDeque transaction = ledger.removeFront();
			double shareCost = transaction.getCostPerShare();
			int numberOfShares = transaction.getNumberOfShares();

			if (numberOfShares > sharesSold) {
				totalCost = totalCost + sharesSold * shareCost;
				int numberToPutBack = numberOfShares - sharesSold;
				StockPurchaseUsingDeque leftOver = new StockPurchaseUsingDeque(numberToPutBack, shareCost);
				ledger.addToFront(leftOver); // Return leftover shares
				// Note: Loop will exit since sharesSold will be <= 0 later
			} else
				totalCost = totalCost + numberOfShares * shareCost;

			sharesSold = sharesSold - numberOfShares;
		}

		return saleAmount - totalCost; // Gain or loss
	}
	
	/**
	 * Show all stocks in the ledger
	 */
	public void display() {
		Object[] stocks = ledger.toArray();
		
		System.out.println("Stocks held");
		for(Object stock : stocks)
			System.out.println("Stock " + stock);
	}
}
